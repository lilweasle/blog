
* Thank you for using the Free Favicon favicon generator!  Here are the contents of this compressed package:

  favicon.ico  --  The favicon file (supports both 16*16 and 32*32 dimensions).

  * You can add a favicon to your web page by uploading favicon.ico to Root of your 
 website and inserting the following HTML tag between the <head> ... </head>
 tags of your web page.

<link rel="shortcut icon" href="favicon.ico">

  * How to use the Animated FavIcon: if you would like to display the animated favicon, upload
 animated_favicon1.gif also and insert the following HTML tags.

<link rel="shortcut icon" href="favicon.ico" >
<link rel="icon" href="animated_favicon1.gif" type="image/gif" >


* Other extra files in this package

  * The following files are included for your convenience. These are optional files:

 - favicon.ico - favicon.
 - preview_16x16.png - 16*16 PNG image file of the favicon.
 - preview_32x32.png - 32*32 PNG image file of the favicon.
 - animated_favicon.gif - animated version of the favicon.
 - readme.txt - this quick reference.

If you are having any problems installing your favicon we have tips on the Free Favicon blog. 
https://www.freefavicon.com/blog/

Thank you once again for using the Free Favicon favicon generator! If you like your favicon we appreciate
you taking the time to mention our service to others, blogging about us and of course by linking to us.

We also encourage you to check out Backblaze online backup. We use Backblaze to backup our computers and keep our data safe. They offer a free 15 day trial and are the easiest online backup service we have used.

Use this link https://www.freefavicon.com/blog/outgoing/backblaze.php to try Backblaze for Free!

By signing up for Backblaze you help keep Free Favicon free!

Thank you,
FreeFavicon.com